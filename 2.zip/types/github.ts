// types/github.ts

export interface Repo {
  name: string;
  languages_url: string;
}

export interface Skill {
  name: string;
  percent: number;
} 