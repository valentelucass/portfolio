"use client"
// components/github-skills.tsx
import { useGithubData } from "../hooks/use-github-data";

interface Props {
  username: string;
}

export function GitHubSkills({ username }: Props) {
  const { skills, loading, error } = useGithubData(username);

  // Skeleton loading
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-16">
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="h-32 bg-zinc-800/50 rounded-2xl shadow-lg animate-pulse flex flex-col justify-between p-6"
          >
            <div className="h-6 w-1/2 bg-zinc-700 rounded mb-4" />
            <div className="w-full h-2.5 bg-zinc-700 rounded-full overflow-hidden mb-2" />
            <div className="h-4 w-1/4 bg-zinc-700 rounded self-end" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <>
      {error && <div className="text-red-400 mb-4">{error}</div>}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-16">
        {skills.map(skill => (
          <div
            key={skill.name}
            className="h-32 bg-zinc-800/50 rounded-2xl shadow-lg backdrop-blur-md border border-zinc-700/50 p-6 flex flex-col justify-between transition-all duration-300 hover:border-cyan-500/70 hover:shadow-2xl relative overflow-hidden group"
          >
            {/* Gradiente de fundo no hover */}
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-2xl blur opacity-0 group-hover:opacity-100 transition duration-700 pointer-events-none" />
            <div className="font-bold text-lg text-white z-10 relative">{skill.name}</div>
            <div className="w-full h-2.5 bg-zinc-700 rounded-full overflow-hidden mb-2 z-10 relative">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-700"
                style={{ width: `${skill.percent}%` }}
              />
            </div>
            <div className="text-right text-sm text-zinc-300 z-10 relative">{skill.percent}%</div>
          </div>
        ))}
      </div>
    </>
  );
} 