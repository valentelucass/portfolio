"use client"
// lib/github.ts
import type { Repo, Skill } from "../types/github";

const CACHE_KEY = "github_skills_cache";
const CACHE_TIME = 60 * 60 * 1000; // 1 hora

export async function fetchGithubSkills(username: string): Promise<Skill[]> {
  // Verifica se localStorage está disponível (só no cliente)
  if (typeof window !== 'undefined') {
    // Tenta cache local
    const cached = localStorage.getItem(CACHE_KEY);
    if (cached) {
      try {
        const { data, timestamp } = JSON.parse(cached);
        if (Date.now() - timestamp < CACHE_TIME) {
          console.log("Usando cache das skills do GitHub");
          return data;
        }
      } catch (error) {
        // Se o cache estiver corrompido, remove
        localStorage.removeItem(CACHE_KEY);
      }
    }
  }

  try {
    console.log("Buscando skills do GitHub para:", username);
    
    // Busca repositórios
    const reposRes = await fetch(`https://api.github.com/users/${username}/repos?per_page=100`);
    if (!reposRes.ok) {
      throw new Error(`Erro ao buscar repositórios: ${reposRes.status}`);
    }
    const repos: Repo[] = await reposRes.json();

    // Busca linguagens de cada repo
    const langStats: Record<string, number> = {};
    for (const repo of repos) {
      try {
        const langRes = await fetch(repo.languages_url);
        if (!langRes.ok) continue;
        const langs = await langRes.json();
        for (const [lang, bytes] of Object.entries(langs)) {
          langStats[lang] = (langStats[lang] || 0) + (bytes as number);
        }
      } catch (error) {
        // Continua para o próximo repo se houver erro
        continue;
      }
    }

    // Calcula percentuais
    const total = Object.values(langStats).reduce((a, b) => a + b, 0);
    if (total === 0) {
      throw new Error("Nenhuma linguagem encontrada nos repositórios");
    }

    const skills: Skill[] = Object.entries(langStats)
      .map(([name, bytes]) => ({ name, percent: Math.round((bytes / total) * 100) }))
      .sort((a, b) => b.percent - a.percent);

    console.log("Skills encontradas:", skills);

    // Salva cache apenas se localStorage estiver disponível
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(CACHE_KEY, JSON.stringify({ data: skills, timestamp: Date.now() }));
        console.log("Cache das skills salvo");
      } catch (error) {
        // Ignora erro de localStorage
      }
    }

    return skills;
  } catch (error) {
    console.error("Erro ao buscar skills do GitHub:", error);
    throw error;
  }
} 